import struct, sys, json, base64, threading, urllib.request, unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import ffx_engine as E

def chunk(cid, body):
    b = struct.pack(">4sI", cid, len(body)) + body
    return b + (b"\x00" if len(body) & 1 else b"")

def make_ffx(version, third_party=False):
    names = [b"ADBE Gaussian Blur 2"] + ([b"VC Optical Flares"] if third_party else [])
    tds = b"".join(chunk(b"LIST", b"tdsp" + chunk(b"tdmn", n.ljust(40, b"\0")) + chunk(b"tdsn", b"Utf8" + struct.pack(">I", 3) + b"Blur")) for n in names)
    body = b"FaFX" + chunk(b"head", struct.pack(">4I", 3, version, 0x44, 0x01000000)) \
        + chunk(b"LIST", b"besc" + chunk(b"beso", struct.pack(">I", 30720) + b"\0" * 12) + tds + chunk(b"ldat", b"\x01\x02\x03")
        + chunk(b"LIST", b"sspc" + chunk(b"fnam", b"Utf8" + struct.pack(">I", 9) + b"Unsharp 1") + chunk(b"pdnm", b"Utf8" + struct.pack(">I", 6) + b"Amount") + chunk(b"ldat", b"\x09\x08\x07")))
    return b"RIFX" + struct.pack(">I", len(body)) + body

def make_aep(code):
    head = bytearray(32); head[33 - 20] = code
    body = b"Egg!" + chunk(b"head", bytes(head)) + chunk(b"LIST", b"Svap" + chunk(b"nhed", b"\x01" * 20))
    return b"RIFX" + struct.pack(">I", len(body)) + body + b"<?xpacket begin><x:xmpmeta>CreatorTool</x:xmpmeta>"

class T(unittest.TestCase):
    def test_aep_downgrade_changes_exactly_byte_33(self):
        src = make_aep(0x5F)
        out, rep = E.convert_aep(src, "After Effects 2020")
        self.assertTrue(rep["ok"] and rep["changed"] and rep["beta"])
        self.assertEqual(out[33], 0x5B); self.assertEqual(len(out), len(src))
        self.assertEqual([i for i in range(len(src)) if src[i] != out[i]], [33])

    def test_aep_refuses_unexpected_layout_and_bad_files(self):
        for bad in (make_aep(0x05), b"RIFX" + b"\0" * 100, b"hello" * 30):
            with self.assertRaises(E.FFXError): E.parse_aep(bad)
        out, rep = E.convert_aep(make_aep(0x5A), "After Effects 2025")
        self.assertFalse(rep["changed"])


    def test_downgrade_only_touches_version_bytes(self):
        src = make_ffx(96)                      # 2025
        out, rep = E.convert(src, "After Effects 2020")
        self.assertTrue(rep["ok"] and rep["changed"])
        self.assertEqual(E.read_version(out), 91)
        self.assertEqual(E.parse(out)["head_fields"][2:], E.parse(src)["head_fields"][2:])

    def test_names_unwrapped_and_branded(self):
        out, rep = E.convert(make_ffx(96), "After Effects 2020")
        self.assertTrue(rep["ok"] and rep["names_converted"] == 3)
        info = E.parse(out); self.assertEqual(info["version"], 91)
        leaves = {}
        for c in info["chunks"]: leaves.setdefault(c["id"], []).append(out[c["start"]:c["start"] + c["size"]])
        self.assertEqual(leaves["tdsn"], [b"Silent1ae\0"])
        self.assertEqual(leaves["fnam"], [b"Silent1ae".ljust(48, b"\0")])
        self.assertEqual(leaves["pdnm"], [b"Amount\0"])         # parameter names keep their text
        self.assertEqual(leaves["ldat"], [b"\x01\x02\x03", b"\x09\x08\x07"])
        self.assertNotIn(b"Utf8", out)

    def test_version_byte_is_byte_27(self):     # matches community docs: head content offset 7
        self.assertEqual(make_ffx(0x5F)[27], 0x5F)

    def test_upgrade_and_same_are_untouched(self):
        for v, t in ((90, "After Effects 2025"), (91, "After Effects 2020")):
            out, rep = E.convert(make_ffx(v), t)
            self.assertTrue(rep["ok"]); self.assertFalse(rep["changed"]); self.assertEqual(out, make_ffx(v))

    def test_unknown_target_refused(self):
        out, rep = E.convert(make_ffx(96), "After Effects CS6")
        self.assertIsNone(out); self.assertFalse(rep["ok"])

    def test_third_party_and_utf8_reported(self):
        _, rep = E.convert(make_ffx(96, third_party=True), "After Effects 2020")
        self.assertIn("VC Optical Flares", rep["scan"]["third_party"])
        self.assertEqual(rep["scan"]["utf8_strings"], 4)
        self.assertTrue(any("third-party" in w for w in rep["warnings"]))

    def test_garbage_rejected(self):
        for bad in (b"hello" * 20, make_ffx(96)[:40], b"RIFX" + b"\0" * 60):
            with self.assertRaises(E.FFXError): E.parse(bad)

    def test_http_end_to_end(self):
        import app
        from http.server import ThreadingHTTPServer
        srv = ThreadingHTTPServer(("127.0.0.1", 0), app.Handler)
        threading.Thread(target=srv.serve_forever, daemon=True).start()
        base = f"http://127.0.0.1:{srv.server_port}"
        req = urllib.request.Request(base + "/convert", json.dumps({"filename": "x.ffx", "target": "After Effects 2022",
              "data": base64.b64encode(make_ffx(96)).decode()}).encode(), {"Content-Type": "application/json"})
        r = json.load(urllib.request.urlopen(req))
        self.assertTrue(r["ok"]); self.assertEqual(r["filename"], "x_AE2022.ffx")
        self.assertEqual(E.read_version(base64.b64decode(r["data"])), 93)
        for p in ("/ffx_engine.py", "/profiles.json"):
            with self.assertRaises(urllib.error.HTTPError): urllib.request.urlopen(base + p)
        self.assertEqual(urllib.request.urlopen(base + "/").status, 200)
        srv.shutdown()

if __name__ == "__main__":
    unittest.main(verbosity=2)
