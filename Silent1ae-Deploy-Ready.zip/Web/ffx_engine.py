"""FFX engine: parse the RIFX container and patch the version gate in the `head` chunk.

Layout (big-endian):
  'RIFX' <u32 size> 'FaFX'
  'head' <u32 16> [u32 3][u32 VERSION][u32 X][u32 0x01000000]   <- version gate = 2nd field
  'LIST' ... 'besc' ... (effect index + parameter data)

A downgrade rewrites ONLY the 4 VERSION bytes. Every other byte is left alone,
and the result is verified byte-for-byte before it is returned.
"""
import struct, json, re, os
from pathlib import Path

PROFILES_PATH = Path(os.environ.get("SILENT1AE_DATA_DIR", Path(__file__).parent)) / "profiles.json"
HEAD_VERSION_FIELD = 4          # offset of VERSION inside the head chunk content
MAX_DEPTH = 32


class FFXError(Exception):
    pass


def load_profiles():
    with open(PROFILES_PATH, "r", encoding="utf-8") as f:
        return json.load(f)


def save_profiles(p):
    tmp = PROFILES_PATH.with_suffix(".tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(p, f, indent=2)
    tmp.replace(PROFILES_PATH)


def _walk(data, start, end, depth, out):
    pos = start
    while pos + 8 <= end:
        cid = bytes(data[pos:pos + 4])
        size = struct.unpack(">I", data[pos + 4:pos + 8])[0]
        cstart = pos + 8
        cend = cstart + size
        if cend > end:
            raise FFXError(f"Chunk {cid!r} at byte {pos} runs past its parent (corrupt or truncated file).")
        out.append({"id": cid.decode("latin-1"), "offset": pos, "start": cstart, "size": size, "depth": depth})
        if cid == b"LIST" and size >= 4 and depth < MAX_DEPTH:
            out[-1]["form"] = bytes(data[cstart:cstart + 4]).decode("latin-1")
            _walk(data, cstart + 4, cend, depth + 1, out)
        pos = cend + (size & 1)   # chunks are padded to even length


def parse(data):
    """Return dict(chunks, head_offset, version). Raises FFXError if not a valid FFX."""
    if len(data) < 32:
        raise FFXError("File is too small to be an FFX preset.")
    if data[0:4] != b"RIFX":
        raise FFXError("Not an FFX preset: missing 'RIFX' signature (is this a different file type?).")
    if data[8:12] != b"FaFX":
        raise FFXError("Not an FFX preset: form type is not 'FaFX'.")
    declared = struct.unpack(">I", data[4:8])[0]
    if declared + 8 > len(data):
        raise FFXError("File is truncated (header says it is larger than it is).")
    chunks = []
    _walk(data, 12, declared + 8, 0, chunks)
    heads = [c for c in chunks if c["id"] == "head" and c["depth"] == 0]
    if not heads or heads[0]["size"] != 16:
        raise FFXError("No valid 16-byte 'head' chunk found.")
    h = heads[0]
    fields = struct.unpack(">4I", data[h["start"]:h["start"] + 16])
    return {
        "chunks": chunks,
        "head_start": h["start"],
        "head_fields": fields,
        "version": fields[1],
    }


def _printable_runs(b, minlen=4):
    return re.findall(rb"[\x20-\x7e]{%d,}" % minlen, b)


def scan(data, info):
    """Heuristic compatibility scan: Utf8-wrapped strings and non-Adobe (third-party) effects."""
    utf8 = sum(1 for c in info["chunks"] if c["id"] in ("tdsn", "pdnm", "fnam")
               and data[c["start"]:c["start"] + 4] == b"Utf8")
    names = []
    for c in info["chunks"]:
        if c["id"] == "tdmn":
            runs = _printable_runs(data[c["start"]:c["start"] + c["size"]])
            if runs:
                names.append(max(runs, key=len).decode("ascii"))
    third = sorted({n for n in names if n and not n.startswith("ADBE") and "sentinel" not in n.lower()})
    return {
        "effects": len([n for n in names if "sentinel" not in n.lower()]),
        "third_party": third,
        "utf8_strings": utf8,
    }


# ───────── effect-name rewrite (newer AE wraps names as 'Utf8'+len+text; older AE shows "Utf8") ─────────
BRAND_NAME = "Silent1ae"            # shown as the effect name; set to None to keep each effect's original name
BRAND_CHUNKS = (b"tdsn", b"fnam")   # effect names. 'pdnm' (parameter names) is unwrapped but never renamed


def _tree(data, start, end, depth=0):
    nodes, pos = [], start
    while pos + 8 <= end:
        cid = bytes(data[pos:pos + 4])
        size = struct.unpack(">I", data[pos + 4:pos + 8])[0]
        cs, ce = pos + 8, pos + 8 + size
        if ce > end:
            raise FFXError("Chunk runs past its parent.")
        if cid == b"LIST" and size >= 4 and depth < MAX_DEPTH:
            nodes.append({"id": cid, "form": bytes(data[cs:cs + 4]), "kids": _tree(data, cs + 4, ce, depth + 1)})
        else:
            nodes.append({"id": cid, "data": bytes(data[cs:ce])})
        pos = ce + (size & 1)
    return nodes


def _ser(nodes):
    out = bytearray()
    for n in nodes:
        body = n["data"] if "data" in n else n["form"] + _ser(n["kids"])
        out += n["id"] + struct.pack(">I", len(body)) + body
        if len(body) & 1:
            out += b"\0"
    return bytes(out)


def _rebuild(data, nodes):
    declared = struct.unpack(">I", data[4:8])[0]
    body = b"FaFX" + _ser(nodes)
    return b"RIFX" + struct.pack(">I", len(body)) + body + bytes(data[declared + 8:])


def _unwrap(b):
    if b[:4] != b"Utf8" or len(b) < 8:
        return None
    n = struct.unpack(">I", b[4:8])[0]
    if 8 + n > len(b):
        return None
    return b[8:8 + n].split(b"\0")[0]


def _leaves(nodes, out=None):
    out = [] if out is None else out
    for n in nodes:
        _leaves(n["kids"], out) if "kids" in n else out.append((n["id"], n["data"]))
    return out


def _fix_names(nodes):
    count = 0
    for n in nodes:
        if "kids" in n:
            count += _fix_names(n["kids"])
            continue
        if n["id"] not in (b"tdsn", b"pdnm", b"fnam"):
            continue
        text = _unwrap(n["data"])
        if text is None:
            continue
        if BRAND_NAME and n["id"] in BRAND_CHUNKS:
            text = BRAND_NAME.encode("utf-8")
        n["data"] = text[:47].ljust(48, b"\0") if n["id"] == b"fnam" else text + b"\0"
        count += 1
    return count


def rewrite_names(data, version):
    """Return (new_bytes, names_converted) with `version` written to head and Utf8 names fixed.
    Raises FFXError (caller falls back) unless the file survives an exact parse->serialize round trip."""
    declared = struct.unpack(">I", data[4:8])[0]
    top = _tree(data, 12, declared + 8)
    if _rebuild(data, top) != bytes(data):
        raise FFXError("File layout does not round-trip exactly; names left untouched.")
    before = _leaves(top)
    head = next(n for n in top if n["id"] == b"head")
    head["data"] = head["data"][:HEAD_VERSION_FIELD] + struct.pack(">I", version) + head["data"][HEAD_VERSION_FIELD + 4:]
    fixed = _fix_names(top)
    out = _rebuild(data, top)
    # verify: re-parses, no wrapped names left, every other chunk byte-identical
    parse(out)
    after = _leaves(_tree(out, 12, struct.unpack(">I", out[4:8])[0] + 8))
    if len(before) != len(after):
        raise FFXError("Internal check failed: chunk count changed.")
    for (i1, d1), (i2, d2) in zip(before, after):
        if i1 not in (b"head", b"tdsn", b"pdnm", b"fnam") and d1 != d2:
            raise FFXError("Internal check failed: a non-name chunk changed.")
        if i2 in (b"tdsn", b"pdnm", b"fnam") and d2[:4] == b"Utf8":
            raise FFXError("Internal check failed: a wrapped name remains.")
    return out, fixed


def version_label(version, profiles):
    for label, p in profiles.items():
        if p["version"] == version:
            return label
    return None


def convert(data, target_label):
    """Downgrade `data` (bytes) to target_label. Returns (new_bytes_or_None, report dict)."""
    profiles = load_profiles()
    info = parse(data)
    src = info["version"]
    src_label = version_label(src, profiles)
    report = {
        "source_version": src,
        "source_label": src_label or f"unknown (version byte {src})",
        "target": target_label,
        "head_fields": list(info["head_fields"]),
        "scan": scan(data, info),
        "warnings": [],
    }
    prof = profiles.get(target_label)
    if prof is None:
        report.update(ok=False, message=f"No version profile for '{target_label}'. Add one from a preset saved natively by that version (see 'Add version profile').")
        return None, report
    report["profile_source"] = prof.get("source", "")
    if prof.get("needs_string_conversion"):
        report.update(ok=False, message=f"{target_label} predates the UTF-8 string format; downgrading that far needs string re-encoding, which this tool does not do. Refusing rather than writing a file that crashes After Effects.")
        return None, report
    tgt = prof["version"]
    if src == tgt:
        report.update(ok=True, changed=False, message=f"Already saved for {target_label}; nothing to change.")
        return bytes(data), report
    if src < tgt:
        report.update(ok=True, changed=False, message=f"This preset (version {src}) is older than {target_label} (version {tgt}); newer After Effects opens older presets, so it was left untouched.")
        return bytes(data), report

    names = 0
    off = info["head_start"] + HEAD_VERSION_FIELD
    if report["scan"]["utf8_strings"]:
        try:
            out, names = rewrite_names(data, tgt)
            out = bytearray(out)
        except FFXError as e:
            report["warnings"].append(str(e))
            names = 0
    if not names:
        out = bytearray(data)
        out[off:off + 4] = struct.pack(">I", tgt)
        diff = [i for i in range(len(data)) if data[i] != out[i]]
        if len(out) != len(data) or any(i < off or i >= off + 4 for i in diff):
            raise FFXError("Internal check failed: bytes outside the version field changed.")
        if parse(bytes(out))["version"] != tgt:
            raise FFXError("Internal check failed: version did not stick.")
    report["names_converted"] = names

    if report["scan"]["third_party"]:
        report["warnings"].append("Contains third-party effects (" + ", ".join(report["scan"]["third_party"][:5]) +
                                  "); they must be installed in the target After Effects.")
    report["warnings"].append("Effects/parameters that do not exist in the target version may load with defaults or be rejected. Open the result once to check.")
    report.update(ok=True, changed=True,
                  message=f"Downgraded from {report['source_label']} to {target_label}" +
                          (f" ({names} effect/parameter names converted)." if names else " (only the 4 version bytes were rewritten)."))
    return bytes(out), report


def read_version(data):
    return parse(data)["version"]


# ───────────────────────── .aep (BETA) ─────────────────────────
# AEP is RIFX with form type 'Egg!'. Community docs (Dszae/After_effects_downgrade, lottie-docs)
# put the AE version code at file byte 33 (0x5E for AE 2023). The bytes after it look like
# build info and are NOT documented, so they are left untouched. Every assumption is checked
# against the real file before anything is written; if it doesn't match, we refuse.
AEP_VERSION_BYTE = 33


def parse_aep(data):
    if len(data) < 64:
        raise FFXError("File is too small to be an After Effects project.")
    if data[0:4] != b"RIFX":
        raise FFXError("Not an .aep: missing 'RIFX' signature (text-based .aepx projects are not supported).")
    if data[8:12] != b"Egg!":
        raise FFXError("Not an After Effects project: form type is not 'Egg!'.")
    declared = struct.unpack(">I", data[4:8])[0]
    if declared + 8 > len(data):
        raise FFXError("File is truncated (header says it is larger than it is).")
    if data[12:16] != b"head":
        raise FFXError("Unexpected layout: first chunk is not 'head'.")
    hsize = struct.unpack(">I", data[16:20])[0]
    if 20 + hsize <= AEP_VERSION_BYTE + 1:
        raise FFXError("Unexpected layout: 'head' chunk is too small to hold the version byte.")
    v = data[AEP_VERSION_BYTE]
    if not 0x40 <= v <= 0x70:
        raise FFXError(f"Unexpected layout: byte {AEP_VERSION_BYTE} is 0x{v:02X}, which is not a known After Effects version code. Refusing to guess.")
    return {"version": v, "build_bytes": data[AEP_VERSION_BYTE:AEP_VERSION_BYTE + 6].hex(),
            "has_xmp": b"<x:xmpmeta" in data[-65536:] or b"<?xpacket" in data[-65536:]}


def convert_aep(data, target_label):
    profiles = load_profiles()
    info = parse_aep(data)
    src = info["version"]
    by_code = {p["version"] & 0xFF: l for l, p in profiles.items()}
    report = {"kind": "aep", "beta": True, "source_version": src,
              "source_label": by_code.get(src, f"unknown (version code 0x{src:02X})"),
              "target": target_label, "build_bytes": info["build_bytes"], "warnings": []}
    prof = profiles.get(target_label)
    if prof is None:
        report.update(ok=False, message=f"No version profile for '{target_label}'.")
        return None, report
    if prof.get("needs_string_conversion"):
        report.update(ok=False, message=f"{target_label} is too old for a safe header-level downgrade.")
        return None, report
    tgt = prof["version"] & 0xFF
    if src == tgt:
        report.update(ok=True, changed=False, message=f"Already saved for {target_label}; nothing to change.")
        return bytes(data), report
    if src < tgt:
        report.update(ok=True, changed=False, message=f"This project is older than {target_label}; newer After Effects opens older projects, so it was left untouched.")
        return bytes(data), report
    out = bytearray(data)
    out[AEP_VERSION_BYTE] = tgt
    diff = [i for i in range(len(data)) if data[i] != out[i]]
    if diff != [AEP_VERSION_BYTE] or len(out) != len(data):
        raise FFXError("Internal check failed: unexpected bytes changed.")
    if parse_aep(bytes(out))["version"] != tgt:
        raise FFXError("Internal check failed: version did not stick.")
    report["warnings"] += [
        "BETA: .aep support is based on community documentation and has not been verified against real projects. Open the result in After Effects before relying on it.",
        "Footage links, missing effects/plug-ins and features newer than the target version are not converted and may be dropped or defaulted.",
    ]
    report.update(ok=True, changed=True, bytes_changed=1,
                  message=f"Downgraded from {report['source_label']} to {target_label} (1 version byte rewritten).")
    return bytes(out), report
