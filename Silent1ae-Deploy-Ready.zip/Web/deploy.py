"""Production WSGI entry point. Run with: gunicorn deploy:app"""
from pathlib import Path
import base64
import binascii
import os
from flask import Flask, jsonify, request, send_from_directory
import ffx_engine as E

BASE = Path(__file__).resolve().parent
MAX_FILE_BYTES = 500 * 1024 * 1024
ALL_TARGETS = [
    "After Effects 2026", "After Effects 2025", "After Effects 2024",
    "After Effects 2023", "After Effects 2022", "After Effects 2021",
    "After Effects 2020", "After Effects 2019", "After Effects 2018",
    "After Effects CC 2017", "After Effects CS6",
]

app = Flask(__name__, static_folder=None)
# Base64 adds ~33%; leave room for JSON envelope.
app.config["MAX_CONTENT_LENGTH"] = ((MAX_FILE_BYTES + 2) // 3) * 4 + 1024 * 1024

@app.after_request
def security_headers(response):
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    response.headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()"
    response.headers["Cache-Control"] = "no-store"
    return response

@app.errorhandler(413)
def too_large(_):
    return jsonify(ok=False, message="File too large (500 MB safety cap)."), 413

@app.get("/")
@app.get("/index.html")
def index():
    return send_from_directory(BASE, "index.html")

@app.get("/static/<path:filename>")
def static_files(filename):
    return send_from_directory(BASE / "static", filename)

@app.get("/health")
def health():
    return jsonify(status="ok")

@app.get("/version")
def version():
    return jsonify(version="v3-silent1ae")

@app.get("/profiles")
def profiles():
    prof = E.load_profiles()
    return jsonify(targets=[
        {"label": label, "available": label in prof,
         "source": prof.get(label, {}).get("source", "")}
        for label in ALL_TARGETS
    ])

def payload():
    body = request.get_json(silent=True)
    if not isinstance(body, dict):
        return None, (jsonify(ok=False, message="Invalid JSON request."), 400)
    filename = Path(str(body.get("filename", ""))).name
    encoded = body.get("data")
    if not filename or not isinstance(encoded, str):
        return None, (jsonify(ok=False, message="Filename and file data are required."), 400)
    try:
        raw = base64.b64decode(encoded, validate=True)
    except (binascii.Error, ValueError):
        return None, (jsonify(ok=False, message="Invalid file data."), 400)
    if not raw or len(raw) > MAX_FILE_BYTES:
        return None, (jsonify(ok=False, message="File is empty or exceeds the 500 MB limit."), 413)
    return (filename, raw, body), None

@app.post("/convert")
def convert():
    item, error = payload()
    if error:
        return error
    filename, raw, body = item
    ext = Path(filename).suffix.lower()
    if ext not in (".ffx", ".aep"):
        return jsonify(ok=False, message="Please upload an .ffx preset or an .aep project."), 400
    try:
        converter = E.convert_aep if ext == ".aep" else E.convert
        out, report = converter(raw, str(body.get("target", "")))
        result = {"ok": report["ok"], "message": report["message"], "report": report}
        if out is not None and report["ok"]:
            suffix = ""
            if report.get("changed"):
                suffix = "_" + "".join(
                    c for c in str(body.get("target", "")).replace("After Effects", "AE")
                    .replace(" ", "") if c.isalnum()
                )
            result["filename"] = f"{Path(filename).stem}{suffix}{ext}"
            result["data"] = base64.b64encode(out).decode("ascii")
        return jsonify(result)
    except E.FFXError as exc:
        return jsonify(ok=False, message=str(exc)), 400

@app.post("/profile")
def add_profile():
    item, error = payload()
    if error:
        return error
    filename, raw, body = item
    if Path(filename).suffix.lower() != ".ffx":
        return jsonify(ok=False, message="Only .ffx presets can be used as version profiles."), 400
    label = str(body.get("label", "")).strip()
    if not label or len(label) > 60 or label not in ALL_TARGETS:
        return jsonify(ok=False, message="Choose a supported After Effects version name."), 400
    try:
        ver = E.read_version(raw)
        prof = E.load_profiles()
        prof[label] = {"version": ver, "source": f"captured from native preset '{filename}'"}
        E.save_profiles(prof)
        return jsonify(ok=True, message=f"Saved profile '{label}' (version byte {ver}).")
    except E.FFXError as exc:
        return jsonify(ok=False, message=str(exc)), 400

if __name__ == "__main__":
    # Convenient local production-like run; hosted platforms use Gunicorn.
    app.run(host="0.0.0.0", port=int(__import__("os").environ.get("PORT", "8000")))
