SILENT1AE CONVERTER  (v3.1)

1. Install Python 3.10+ (python.org). Nothing else to install.
2. Extract the WHOLE zip, open the inner folder, double-click START-WINDOWS.bat.
3. Open http://127.0.0.1:8765 (Ctrl+F5). Footer must say v3.
4. Pick Presets (.ffx) or Projects (.aep), drop files, pick a version, Downgrade now.

HOW IT WORKS
Both formats are RIFX containers; After Effects checks a version code in the file
header. This tool rewrites ONLY that code and verifies the result byte-for-byte.
  .ffx : 'head' chunk, version field (file byte 27).
  .aep : file byte 33 (BETA - from community docs, not verified on real projects;
         refuses files whose layout doesn't match). Build bytes after it are untouched.
Originals are never modified. Presets/projects already older than the target are
left as-is (newer After Effects opens older files).

VERSION TABLE (profiles.json) - AE 2019-2025 values come from a community table and
are unverified. Use "Add version profile" with a preset saved natively in a version
to capture its true byte (needed for 2026, 2018, 2017, CS6).

LIMITS
- Cannot add effects/plug-ins missing from the target version.
- .aep: footage links and newer features are not converted. Text .aepx unsupported.
- CS6 and older need string re-encoding; refused rather than risk a crash.
- Tests (python tests/test_engine.py) use synthetic files; confirm real results in AE.

INTERNET DEPLOYMENT
See README-DEPLOY.md. Production hosting uses deploy.py + requirements.txt + Gunicorn.
The original START-WINDOWS.bat remains for local-only use.
