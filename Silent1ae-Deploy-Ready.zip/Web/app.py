from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import json, base64
import ffx_engine as E

BASE = Path(__file__).parent
MAX_BYTES = 500 * 1024 * 1024
ALL_TARGETS = ["After Effects 2026", "After Effects 2025", "After Effects 2024", "After Effects 2023",
               "After Effects 2022", "After Effects 2021", "After Effects 2020", "After Effects 2019",
               "After Effects 2018", "After Effects CC 2017", "After Effects CS6"]


class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(BASE), **kwargs)

    def end_headers(self):
        # never let the browser reuse an old copy of the page or script
        self.send_header("Cache-Control", "no-store")
        super().end_headers()

    def _json(self, obj, code=200):
        body = json.dumps(obj).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _read_payload(self):
        length = int(self.headers.get("Content-Length", "0"))
        if length > MAX_BYTES:
            self._json({"ok": False, "message": "File too large (500 MB safety cap)."}, 413)
            return None
        try:
            p = json.loads(self.rfile.read(length))
            p["_name"] = Path(p["filename"]).name
            p["_data"] = base64.b64decode(p["data"])
            return p
        except Exception:
            self._json({"ok": False, "message": "Invalid upload."}, 400)
            return None

    def do_GET(self):
        if self.path == "/version":
            return self._json({"version": VERSION})
        if self.path == "/profiles":
            prof = E.load_profiles()
            return self._json({"targets": [{"label": t, "available": t in prof,
                                            "source": prof.get(t, {}).get("source", "")} for t in ALL_TARGETS]})
        # only serve the UI, never source files or profiles.json directly
        if self.path in ("/", "/index.html") or self.path.startswith("/static/"):
            return super().do_GET()
        self.send_error(404)

    def do_POST(self):
        if self.path not in ("/convert", "/profile"):
            return self.send_error(404)
        p = self._read_payload()
        if p is None:
            return
        ext = Path(p["_name"]).suffix.lower()
        if ext not in (".ffx", ".aep") or (self.path == "/profile" and ext != ".ffx"):
            return self._json({"ok": False, "message": "Please upload an .ffx preset or an .aep project."}, 400)
        try:
            if self.path == "/convert":
                conv = E.convert_aep if ext == ".aep" else E.convert
                out, rep = conv(p["_data"], p.get("target", ""))
                resp = {"ok": rep["ok"], "message": rep["message"], "report": rep}
                if out is not None and rep["ok"]:
                    stem = Path(p["_name"]).stem
                    suffix = "" if not rep.get("changed") else "_" + "".join(
                        c for c in p["target"].replace("After Effects", "AE").replace(" ", "") if c.isalnum())
                    resp["filename"] = f"{stem}{suffix}{ext}"
                    resp["data"] = base64.b64encode(out).decode()
                return self._json(resp)
            # /profile: learn the version byte from a preset saved natively by the target version
            label = str(p.get("label", "")).strip()
            if not label or len(label) > 60:
                return self._json({"ok": False, "message": "Give the profile a short name."}, 400)
            ver = E.read_version(p["_data"])
            prof = E.load_profiles()
            prof[label] = {"version": ver, "source": f"captured from native preset '{p['_name']}'"}
            E.save_profiles(prof)
            return self._json({"ok": True, "message": f"Saved profile '{label}' (version byte {ver})."})
        except E.FFXError as e:
            return self._json({"ok": False, "message": str(e)})


VERSION = "v3-silent1ae"

if __name__ == "__main__":
    try:
        srv = ThreadingHTTPServer(("127.0.0.1", 8765), Handler)
    except OSError:
        print("\nERROR: port 8765 is already in use - an OLD copy of this app is still running.")
        print("Close every black server window (or restart the PC), then run this again.")
        input("Press Enter to close...")
        raise SystemExit(1)
    print(f"Silent1ae Converter {VERSION}\nOpen http://127.0.0.1:8765 in your browser")
    srv.serve_forever()
