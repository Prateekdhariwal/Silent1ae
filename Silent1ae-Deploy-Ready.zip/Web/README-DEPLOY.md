# Silent1ae Converter — internet deployment

## Deploy on Render (recommended)
1. Extract this ZIP and push the **contents of the `Web` folder** to a GitHub repository.
2. In Render, choose **New → Blueprint**, connect the repository, and let it read `render.yaml`.
3. Deploy. Render builds from `requirements.txt`, starts Gunicorn, and checks `/health`.
4. Open the generated `https://....onrender.com` URL.

The included Render persistent disk is mounted at `/var/data`; custom version profiles are stored there and survive deploys/restarts.
For other hosts, install `requirements.txt` and run:
`gunicorn deploy:app --bind 0.0.0.0:$PORT --workers 2 --threads 4 --timeout 300`

## Important production notes
- The app accepts uploads up to 500 MB; base64 JSON requests need additional memory.
  Use a host with enough RAM and request-size limits. Large projects can take time.
- Conversion happens on the server, so unlike the original local-only mode, uploaded
  files are transmitted to and processed by the hosting provider. Do not upload
  confidential projects unless you trust that provider.
- Files are processed in memory and are not intentionally saved. Custom version profiles
  are saved in `profiles.json`; use persistent storage if you want them retained.
- This is a header-level compatibility tool, not a full project converter. Missing
  effects, plugins, footage and newer features are not converted. `.aep` remains BETA.
  Keep backups and test output in After Effects before production use.
- The built-in profile editor is restricted to the supported version labels.
- HTTPS is provided by the hosting platform; always use the HTTPS deployment URL.

## Run locally
The original `START-WINDOWS.bat` still runs the local development server on port 8765.
For a production-like local run: `pip install -r requirements.txt` then
`python deploy.py` (port 8000).
