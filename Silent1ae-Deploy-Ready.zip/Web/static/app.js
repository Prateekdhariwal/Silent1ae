const $=id=>document.getElementById(id);
const esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const reduce=matchMedia('(prefers-reduced-motion: reduce)').matches;
const input=$('files'),drop=$('drop'),list=$('filelist'),btn=$('convert'),results=$('results'),pills=$('pills'),tabs=$('tabs'),panel=$('panel');
let kind='ffx',selected=[],target=null,targets=[],busy=false;

/* ───────── particle field (reacts to the mouse, bursts on success) ───────── */
const cv=$('bg'),cx=cv.getContext('2d');let W,H,DPR,parts=[],mouse={x:-999,y:-999},bursts=[];
function size(){DPR=Math.min(devicePixelRatio||1,2);W=cv.width=innerWidth*DPR;H=cv.height=innerHeight*DPR;
 const n=Math.round(Math.min(110,innerWidth*innerHeight/14000));
 parts=Array.from({length:n},()=>({x:Math.random()*W,y:Math.random()*H,vx:(Math.random()-.5)*.25*DPR,vy:(Math.random()-.5)*.25*DPR,r:(Math.random()*1.6+.5)*DPR,h:Math.random()}))}
addEventListener('resize',size);size();
addEventListener('pointermove',e=>{mouse.x=e.clientX*DPR;mouse.y=e.clientY*DPR});
function frame(){cx.clearRect(0,0,W,H);
 for(const p of parts){p.x+=p.vx;p.y+=p.vy;if(p.x<0||p.x>W)p.vx*=-1;if(p.y<0||p.y>H)p.vy*=-1;
  const dx=p.x-mouse.x,dy=p.y-mouse.y,d=Math.hypot(dx,dy),R=170*DPR;
  if(d<R){const f=(1-d/R)*.9;p.x+=dx/d*f*2;p.y+=dy/d*f*2}
  cx.fillStyle=`hsla(${262+p.h*60},90%,${72+p.h*14}%,${.35+p.h*.45})`;cx.beginPath();cx.arc(p.x,p.y,p.r,0,7);cx.fill()}
 for(let i=0;i<parts.length;i++)for(let j=i+1;j<parts.length;j++){const a=parts[i],b=parts[j],d=Math.hypot(a.x-b.x,a.y-b.y),L=120*DPR;
  if(d<L){cx.strokeStyle=`rgba(167,139,250,${(1-d/L)*.22})`;cx.lineWidth=DPR*.8;cx.beginPath();cx.moveTo(a.x,a.y);cx.lineTo(b.x,b.y);cx.stroke()}}
 for(let i=bursts.length-1;i>=0;i--){const b=bursts[i];b.x+=b.vx;b.y+=b.vy;b.vy+=.12*DPR;b.life-=.016;
  if(b.life<=0){bursts.splice(i,1);continue}
  cx.fillStyle=`hsla(${b.h},95%,70%,${b.life})`;cx.fillRect(b.x,b.y,b.s,b.s)}
 requestAnimationFrame(frame)}
if(!reduce)frame();
function burst(el){if(reduce)return;const r=el.getBoundingClientRect(),ox=(r.left+r.width/2)*DPR,oy=(r.top+r.height/2)*DPR;
 for(let i=0;i<70;i++){const a=Math.random()*Math.PI*2,s=(Math.random()*7+2)*DPR;
  bursts.push({x:ox,y:oy,vx:Math.cos(a)*s,vy:Math.sin(a)*s-4*DPR,life:1+Math.random()*.6,h:260+Math.random()*80,s:(Math.random()*5+2)*DPR})}}

/* ───────── panel: cursor glow + gentle 3D tilt ───────── */
panel.addEventListener('pointermove',e=>{const r=panel.getBoundingClientRect(),x=e.clientX-r.left,y=e.clientY-r.top;
 panel.style.setProperty('--mx',x+'px');panel.style.setProperty('--my',y+'px');
 if(!reduce&&innerWidth>700)panel.style.transform=`perspective(1200px) rotateX(${((y/r.height)-.5)*-2.4}deg) rotateY(${((x/r.width)-.5)*3.2}deg)`});
panel.addEventListener('pointerleave',()=>panel.style.transform='');
btn.addEventListener('pointermove',e=>{if(btn.disabled||reduce)return;const r=btn.getBoundingClientRect();
 btn.style.transform=`translate(${(e.clientX-r.left-r.width/2)*.05}px,${(e.clientY-r.top-r.height/2)*.18-3}px)`});
btn.addEventListener('pointerleave',()=>btn.style.transform='');

/* ───────── tabs ───────── */
const COPY={ffx:{t:'Add your preset files',d:'Drop .ffx files here',a:'.ffx'},aep:{t:'Add your project files',d:'Drop .aep projects here',a:'.aep'}};
function setKind(k){kind=k;tabs.dataset.k=k;tabs.querySelectorAll('.tab').forEach(t=>{const on=t.dataset.kind===k;t.classList.toggle('on',on);t.setAttribute('aria-selected',on)});
 $('s1title').textContent=COPY[k].t;$('droptitle').textContent=COPY[k].d;input.accept=COPY[k].a;input.value='';setFiles([]);results.innerHTML=''}
tabs.querySelectorAll('.tab').forEach(t=>t.addEventListener('click',()=>t.dataset.kind!==kind&&setKind(t.dataset.kind)));

/* ───────── version pills ───────── */
const SUB={'After Effects 2026':'v26','After Effects 2025':'v25','After Effects 2024':'v24','After Effects 2023':'v23','After Effects 2022':'v22','After Effects 2021':'v18','After Effects 2020':'v17','After Effects 2019':'CC 2019 · v16','After Effects 2018':'CC 2018 · v15','After Effects CC 2017':'v14','After Effects CS6':'v11'};
async function loadTargets(){targets=(await (await fetch('/profiles')).json()).targets;
 if(!targets.find(t=>t.label===target&&t.available))target=(targets.find(t=>t.label==='After Effects 2020'&&t.available)||targets.find(t=>t.available)||{}).label||null;
 pills.innerHTML='';targets.filter(t=>t.available).forEach((t,i)=>{const b=document.createElement('button');b.type='button';b.className='pill'+(t.label===target?' on':'');b.disabled=!t.available;b.style.setProperty('--i',i);
  b.setAttribute('role','radio');b.setAttribute('aria-checked',t.label===target);
  b.innerHTML=`<b>${esc(t.label.replace('After Effects ','AE '))}</b><small>${t.available?esc(SUB[t.label]||''):'needs profile'}</small>`;
  b.onclick=()=>{target=t.label;pills.querySelectorAll('.pill').forEach(p=>{p.classList.remove('on');p.setAttribute('aria-checked',false)});b.classList.add('on');b.setAttribute('aria-checked',true)};
  pills.appendChild(b)});sync()}
loadTargets();

/* ───────── files ───────── */
function fmt(n){return n<1024?n+' B':n<1048576?(n/1024).toFixed(1)+' KB':(n/1048576).toFixed(1)+' MB'}
function setFiles(files){selected=[...files].filter(f=>f.name.toLowerCase().endsWith(COPY[kind].a));render();
 if(files.length&&!selected.length)results.innerHTML=`<div class="res bad"><div class="row"><div class="badge"><svg class="cross" viewBox="0 0 24 24"><path d="M6 6l12 12M18 6L6 18"/></svg></div><div><h4>No ${COPY[kind].a} files found</h4><p>You're on the ${kind==='ffx'?'Presets':'Projects'} tab — it only takes ${COPY[kind].a} files.</p></div></div></div>`;else if(selected.length)results.innerHTML=''}
function render(){list.innerHTML='';selected.forEach((f,i)=>{const el=document.createElement('div');el.className='file';el.style.setProperty('--i',i);
 el.innerHTML=`<span class="nm"><span class="ext">${COPY[kind].a.slice(1).toUpperCase()}</span><b>${esc(f.name)}</b></span><span style="display:flex;gap:10px;align-items:center"><span class="sz">${fmt(f.size)}</span><button class="x" aria-label="Remove">×</button></span>`;
 el.querySelector('.x').onclick=()=>{selected.splice(i,1);render()};list.appendChild(el)});sync()}
function sync(){btn.disabled=busy||!selected.length||!target}
input.addEventListener('change',e=>setFiles(e.target.files));
['dragenter','dragover'].forEach(ev=>drop.addEventListener(ev,e=>{e.preventDefault();drop.classList.add('over')}));
['dragleave','drop'].forEach(ev=>drop.addEventListener(ev,e=>{e.preventDefault();drop.classList.remove('over')}));
drop.addEventListener('drop',e=>setFiles(e.dataTransfer.files));

/* ───────── convert ───────── */
function b64(bytes){let b='';for(let i=0;i<bytes.length;i+=0x8000)b+=String.fromCharCode(...bytes.subarray(i,i+0x8000));return btoa(b)}
const fileB64=async f=>b64(new Uint8Array(await f.arrayBuffer()));
function save(name,data){const bin=atob(data),u=new Uint8Array(bin.length);for(let i=0;i<bin.length;i++)u[i]=bin.charCodeAt(i);
 const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([u],{type:'application/octet-stream'}));a.download=name;document.body.appendChild(a);a.click();a.remove()}
const ICON={ok:'<svg class="tick" viewBox="0 0 24 24"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>',
 bad:'<svg class="cross" viewBox="0 0 24 24"><path d="M6 6l12 12M18 6L6 18"/></svg>',
 skip:'<svg class="info" viewBox="0 0 24 24"><path d="M12 8v.01M12 12v5"/></svg>',work:'<div class="spin"></div>'};
function card(f){const el=document.createElement('div');el.className='res work';el.innerHTML=`<div class="row"><div class="badge">${ICON.work}</div><div><h4>${esc(f.name)}</h4><p>Reading file…</p></div></div>`;results.appendChild(el);return el}
function fill(el,f,out){const rep=out.report||{};const state=!out.ok?'bad':rep.changed===false?'skip':'ok';el.className='res '+state;
 let h=`<div class="row"><div class="badge">${ICON[state]}</div><div><h4>${esc(f.name)}</h4><p${state==='bad'?` title="${esc(out.message||'')}"`:''}>${state==='bad'?'Conversion failed':esc(out.message||'')}</p>`;
 if(state==='ok'&&rep.source_label)h+=`<div class="route"><span>${esc(rep.source_label.replace('After Effects ','AE '))}</span><i>➜</i><span>${esc(rep.target.replace('After Effects ','AE '))}</span></div>`;
  if(out.data)h+=`<button class="dl">⬇ Download ${esc(out.filename)}</button>`;
 el.innerHTML=h+`</div></div>`+(state==='ok'?'<div class="bar"></div>':'');
 if(out.data)el.querySelector('.dl').onclick=()=>save(out.filename,out.data);
 if(state==='ok'){burst(el.querySelector('.badge'));save(out.filename,out.data)}}
btn.addEventListener('click',async()=>{busy=true;btn.classList.add('busy');sync();results.innerHTML='';
 for(const f of selected){const el=card(f);try{
  const [res]=await Promise.all([fetch('/convert',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({filename:f.name,data:await fileB64(f),target})}),new Promise(r=>setTimeout(r,450))]);
  fill(el,f,await res.json())}catch(err){fill(el,f,{ok:false,message:err.message})}}
 busy=false;btn.classList.remove('busy');sync()});

/* ───────── version profile capture ───────── */
$('psave').addEventListener('click',async()=>{const f=$('pfile').files[0],l=$('plabel').value.trim(),ps=$('pstatus');
 if(!f||!l){ps.textContent='Choose a preset and enter a name.';return}
 const r=await (await fetch('/profile',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({filename:f.name,data:await fileB64(f),label:l})})).json();
 ps.textContent=r.message;loadTargets()});
